Install the proper packages in order to run the code:

pygame, numpy

For this you can use pip

All files should be is the same folder

