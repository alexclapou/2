import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('192.168.0.101', 9998))
msg = 'asd'
s.send(msg.encode())
print(s.recv(100))
s.send(b"XX")
