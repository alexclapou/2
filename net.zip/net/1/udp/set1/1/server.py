import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(("0.0.0.0", 3333))
data, addr = s.recvfrom(100)
data *= 2
s.sendto(data, addr)
